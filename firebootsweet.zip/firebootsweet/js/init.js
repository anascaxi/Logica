var firebaseConfig = {
    apiKey: "AIzaSyA07pmt6gIJb58m-DWkKHevZ5Vwg1ZzYKI",
    authDomain: "todo-list-7c5e7.firebaseapp.com",
    databaseURL: "https://todo-list-7c5e7.firebaseio.com",
    projectId: "todo-list-7c5e7",
    storageBucket: "todo-list-7c5e7.appspot.com",
    messagingSenderId: "564845935366",
    appId: "1:564845935366:web:84987243e51b213476bc87"
  };

  firebase.initializeApp(firebaseConfig);